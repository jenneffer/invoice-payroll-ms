<?php

return [
    'site_title' => 'IPMS',
];
