Hello <i>{{ $demo->receiverName }}</i>,
<p>Please find attached your Payslip</p>
 
Thank You,
<br/>
<i>{{ $demo->sender }}</i>