
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('styles'); ?>
<style>
    .form-item{
        clear: left;
    } 
    .emp_label{
        float: left;
        width: 150px;
        clear: right;
    }
</style>
<?php $__env->stopSection(); ?>
<div class="card">
    <div class="card-header">
        Show Payroll
    </div>

    <div class="card-body">
        <div class="form-group">
            <!-- <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.payrolls.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div> -->
            <div class="form-item">
                <label class="emp_label">Employee Name</label>
                <p>:&nbsp;<?php echo e($employee_data->emp_name ?? ''); ?></p>
            </div>
            <div class="form-item">
                <label class="emp_label">Date</label>
                <p>:&nbsp;<?php echo e($employee_data->payroll_date ?? ''); ?></p>
            </div>
            <div class="form-item">
                <label class="emp_label">Email</label>
                <p>:&nbsp;<?php echo e($employee_data->emp_email ?? ''); ?></p>
            </div>
            
            <div class="form-group">
                Job Details:
            </div>
            <table class="table table-bordered table-striped">
                <thead>
                    <th>Date</th>
                    <th>Job</th>
                    <th>Time Start</th>
                    <th>Time End</th>
                    <th class="text-center">Rest Time(Min)</th>
                    <th class="text-center">Total(Hours)</th>
                    <th class="text-center">Total(Bin)</th>
                    <th class="text-center">Rate(AUD)</th>
                    <th class="text-right">Total(AUD)</th>
                </thead>
                <tbody>
                    <?php
                    $total_salary = 0;                    
                    ?>
                    <?php $__currentLoopData = $timesheet->payroll_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $total_salary += $p->total;
                        ?>
                        <tr data-entry-id="<?php echo e($p->id); ?>">
                            <td><?php echo e(date('d-m-Y', strtotime($p->date)) ?? ''); ?></td>
                            <td><?php echo e(App\Job::getJobName($p->job_id) ?? ''); ?></td>
                            <td><?php echo e($p->time_start ?? ''); ?></td>
                            <td><?php echo e($p->time_end ?? ''); ?></td>
                            <td class="text-center"><?php echo e($p->time_rest ?? ''); ?></td>
                            <td class="text-center"><?php echo e($p->total_hours ?? ''); ?></td>
                            <td class="text-center"><?php echo e($p->total_bin ?? ''); ?></td>
                            <td class="text-center"><?php echo e(number_format($p->rate,2) ?? ''); ?></td>
                            <td class="text-right"><?php echo e(number_format($p->total,2) ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="8" class="text-right"><b>Total (AUD)</b></td>
                        <td class="text-right"><b><?php echo e(number_format($total_salary,2)); ?></b></td>
                    </tr>
                    <tr>                        
                        <td colspan="8" class="text-right"><b>Bonus/Allowance etc (AUD)</b></td>
                        <td class="text-right"><b>+ <?php echo e(number_format(($employee_data->allowance ?? 0),2)); ?></b></td>
                    </tr>
                    <tr>
                        <td colspan="8" class="text-right"><b>Deduction Others (AUD)</b></td>
                        <td class="text-right"><b>- <?php echo e(number_format(($employee_data->deduction??0),2)); ?></b></td>
                    </tr>
                    <tr>
                        <td colspan="8" class="text-right"><b>Deduction Tax (AUD)</b></td>
                        <td class="text-right"><b>- <?php echo e(number_format(($employee_data->emp_tax??0),2)); ?></b></td>
                    </tr>
                    <tr>                        
                        <td colspan="8" class="text-right"><b>Grandtotal (AUD)</b></td>
                        <td class="text-right"><b><?php echo e(number_format((($total_salary+($employee_data->allowance??0)) - (($employee_data->deduction??0) + ($employee_data->emp_tax??0))),2)); ?></b></td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.timesheet.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Monthly-Invoices\resources\views/admin/timesheet/show.blade.php ENDPATH**/ ?>