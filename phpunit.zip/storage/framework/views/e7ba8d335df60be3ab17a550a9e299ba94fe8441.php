
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Create Job
    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.jobs.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>            
            <div class="form-group <?php echo e($errors->has('job_name') ? 'has-error' : ''); ?>">
                <label for="job_name">Job Name <span style="color:red;">*</span></label>
                <input type="text" id="job_name" name="job_name" class="form-control" value="<?php echo e(old('job_name', isset($jobs) ? $jobs->job_name : '')); ?>" required>
                <?php if($errors->has('job_name')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('job_name')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block"></p>
            </div>
            <div class="form-group <?php echo e($errors->has('job_pay_method') ? 'has-error' : ''); ?>">
                <label for="job_pay_method">Payment Method <span style="color:red;">*</span></label>
                <select class="form-control" name="job_pay_method" id="job_pay_method">
                    <option value="bin">Bin(s)</option>
                    <option value="hour">Hour(s)</option>                    
                </select>
                <?php if($errors->has('job_pay_method')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('job_pay_method')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block"></p>
            </div>                                                
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Monthly-Invoices\resources\views/admin/jobs/create.blade.php ENDPATH**/ ?>