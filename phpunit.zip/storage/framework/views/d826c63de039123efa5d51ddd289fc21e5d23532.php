
<p>Please find attached your Payslip</p>
 
Thank You,
<br/>
<?php /**PATH C:\xampp\htdocs\Laravel-Monthly-Invoices\resources\views/mails/email_template.blade.php ENDPATH**/ ?>