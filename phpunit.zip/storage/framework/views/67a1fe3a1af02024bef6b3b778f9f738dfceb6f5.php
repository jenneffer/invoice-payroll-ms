Hello <i><?php echo e($demo->receiverName); ?></i>,
<p>Please find attached your Payslip</p>
 
Thank You,
<br/>
<i><?php echo e($demo->sender); ?></i><?php /**PATH C:\xampp\htdocs\Laravel-Monthly-Invoices\resources\views/mails/email_template.blade.php ENDPATH**/ ?>