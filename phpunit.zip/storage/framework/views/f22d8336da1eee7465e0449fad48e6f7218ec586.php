
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.invoice.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <!-- <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.payrolls.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div> -->
            <div class="form-group row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Farm Company:</label>
                        <?php echo e($invoice->farm_company->comp_name); ?>

                    </div>
                    <div class="form-group">
                        <label>Address :</label>
                        <?php echo e($invoice->farm_company->comp_address); ?>

                    </div>
                    <div class="form-group">
                        <label>Contact Person :</label>
                        <?php echo e($invoice->farm_company->contact_person); ?>

                    </div>
                    <div class="form-group">
                        <label>Mobile No :</label>
                        <?php echo e($invoice->farm_company->contact_no); ?>

                    </div>
                    <div class="form-group">
                        <label>Email :</label>
                        <?php echo e($invoice->farm_company->email); ?>

                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Invoice Date :</label>
                        <?php echo e(date('d-m-Y', strtotime($invoice->date))); ?>

                    </div>
                    <div class="form-group">
                        <label>Invoice No :</label>
                        <?php echo e($invoice->invoice_number); ?>

                    </div>  
                    <div class="form-group">
                        <label>Bank :</label>
                        <?php echo e($invoice->bank); ?>

                    </div>
                    <div class="form-group">
                        <label>BSB :</label>
                        <?php echo e($invoice->bsb); ?>

                    </div>
                    <div class="form-group">
                        <label>Account No :</label>
                        <?php echo e($invoice->acc_no); ?>

                    </div>                             
                </div>
                <br>
            </div>   
            <div class="form-group float-none">
                <p>Ref. (Work report from) :</p>
            </div>                                         
            <table class="table table-bordered table-striped">
                <thead>
                    <th>Date</th>
                    <th>Description</th>
                    <th class="text-right">Amount Charged(AUD)</th>                    
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invoice->invoice_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                        <tr data-entry-id="<?php echo e($inv->id); ?>">
                            <td><?php echo e(date('d-m-Y', strtotime($inv->date)) ?? ''); ?></td>
                            <td><?php echo e($inv->description ?? ''); ?></td>
                            <td class="text-right"><?php echo e(number_format($inv->amount_charged,2) ?? ''); ?></td>                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="2" class="text-right"><b>Sub Total (AUD)</b></td>
                        <td class="text-right"><b><?php echo e($invoice->sub_total); ?></b></td>
                    </tr>
                    <?php if($invoice->farm_company->super == 1 ): ?>
                    <tr>
                        <td colspan="2" class="text-right"><b>Super (9.5%)</b></td>
                        <td class="text-right"><b><?php echo e($invoice->super_amount); ?></b></td>
                    </tr>
                    <?php endif; ?>
                    <tr>                        
                        <td colspan="2" class="text-right"><b>GST (10%)</b></td>
                        <td class="text-right"><b><?php echo e($invoice->gst); ?></b></td>
                    </tr>
                    <tr>                        
                        <td colspan="2" class="text-right"><b>Total Amount (AUD)</b></td>
                        <td class="text-right"><b><?php echo e(number_format($invoice->total_amount,2)); ?></b></td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group" style="text-align:center;">
                <a class="btn btn-default" href="<?php echo e(route('admin.invoices.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>                
                <!-- <a class="btn btn-success" href="">
                    Send Email
                </a> -->
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Monthly-Invoices\resources\views/admin/invoices/show.blade.php ENDPATH**/ ?>